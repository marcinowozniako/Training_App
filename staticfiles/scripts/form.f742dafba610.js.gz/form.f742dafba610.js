$('#id_exercise').select2()
$('#id_exercise_name').select2()
// if(document.title === 'Training Log Add Exercises to Trening'){
//     $('#select2-id_exercise_name-container').css('font-size', '1.25rem')
// }


