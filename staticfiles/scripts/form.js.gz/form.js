if (document.title==='Training Log Workout'){
    const date = document.getElementById('id_date')
date.type = 'date'
}

if (document.title==='Training Log Workout List'){
    const text = document.querySelector('#text')
console.log(text)
}
